import sys
import json
import asyncio
import websockets
import getpass
import os
import math
import random
import time
from game import *
from mapa import Map
# Next 2 lines are not needed for AI agent
#import pygame

#pygame.init()


class Node:
    def __init__(self, cost, coord, parent=None):
        if parent != None:
            self.parent = parent
        else:
            self.parent = None
        self.coord = coord
        self.H = 0
        self.G = cost
        self.F = 0


async def agent_loop(server_address="localhost:8000", agent_name="student"):
    # definir funções aqui

    def objective(bomber, walls, enemies):
        en = []
        for e in state.get('enemies'):
            en.append(e['pos'])
        array = []
        [px, py] = bomber
        lista = [(math.sqrt((px - x) ** 2 + (py - y) ** 2), x, y) for x in range(1, mapa.hor_tiles) for y in
                 range(1, mapa.ver_tiles) if [x, y] in walls]  # 1 ou 0 no x?
        sortedList = sorted(lista, key=lambda l: l[0])  # encontra a wall mais proxima
        lista1 = [(math.sqrt((px - x) ** 2 + (py - y) ** 2), x, y) for x, y in en]
        sortedList2 = sorted(lista1, key=lambda x: x[0])
        # lista1 = [distanceTo(enemies[x],bomber),enemies[x])]
        x1, y1, z1 = sortedList[0]
        if mapa.map[y1][z1 - 1] == 0:  # encontra uma posição livre perto da wall mais próxima
            array.append([math.sqrt((px - y1) ** 2 + (py - (z1 - 1)) ** 2), y1, (z1 - 1)])
        if mapa.map[y1 - 1][z1] == 0:
            array.append([math.sqrt((px - (y1 - 1)) ** 2 + (py - z1) ** 2), (y1 - 1), z1])
        if mapa.map[y1 + 1][z1] == 0:
            array.append([math.sqrt((px - (y1 + 1)) ** 2 + (py - z1) ** 2), (y1 + 1), z1])
        if mapa.map[y1][z1 + 1] == 0:
            array.append([math.sqrt((px - y1) ** 2 + (py - (z1 + 1)) ** 2), y1, (z1 + 1)])
        sortedList1 = sorted(array, key=lambda l: l[0])
        z2, y2, x2 = sortedList1[0]
        if len(sortedList2) !=0:
            z3, y3, x3 = sortedList2[0]

        #if (z2 > z3):
         #   return [y3, x3]
        #else:
        return [y2, x2]

    def pressKey(bmbpos, nextpos, objective, bomba, en, walls,path):  # done
        bx, by = bmbpos
        nx, ny = nextpos
        ox, oy = objective
        if (bx == ox and by == oy) and len(bomba) == 0:
            #path=[]
            return "B"
        if len(bomba) == 0 and len(walls) == 0:
            for a in en:
                #print(a)
                ex, ey = a
                if (bx - 2 == ex and by == ey) or (bx + 2 == ex and by == ey) or (by - 2 == ey and bx == ex) or (
                        by + 2 == ey and bx == ex):
                    #path =[]
                    return "B"
       # if len(bomba) == 0:
        #    for a in en:
         #       [ex,ey] = a
          #      if ((bx== ex + 3 and by == ey) and not [bx-1,by] in walls) or ((by== ey+3 and bx == ex) and not [bx,by-1] in walls) or ((bx== ex - 3 and by == ey) and not [bx+1,by] in walls) or ((by== ey-3 and bx == ex) and not [bx,by+1] in walls):
           #         path=[]
            #        return "B"
        if bx < nx and by == ny:
            return "d"
        if bx > nx and by == ny:
            return "a"
        if by < ny and bx == nx:
            return "s"
        if by > ny and bx == nx:
            return "w"
        return ""

    def checkEqual(lst):
        return lst[1:] == lst[:-1]

    def distanceTo(celula, objective):
        [x, y] = celula
        [x1, y1] = objective
        return math.sqrt((x - x1) ** 2 + (y - y1) ** 2)

    def neighbors(celula):
        [x, y] = celula
        neighbors = []
        if not mapa.is_blocked([x - 1, y]):
            neighbors.append([x - 1, y])
        if not mapa.is_blocked([x + 1, y]):
            neighbors.append([x + 1, y])
        if not mapa.is_blocked([x, y - 1]):
            neighbors.append([x, y - 1])
        if not mapa.is_blocked([x, y + 1]):
            neighbors.append([x, y + 1])
        if mapa.is_blocked([x-1,y]):
            if not mapa.is_blocked([x+1,y]):
                neighbors.append([x+1,y])
            if mapa.is_blocked([x+1,y]):
                neighbors.append([x,y+1])
                neighbors.append([x, y - 1])
        if mapa.is_blocked([x+1, y]):
            if not mapa.is_blocked([x - 1, y]):
                neighbors.append([x - 1, y])
            if mapa.is_blocked([x - 1, y]):
                neighbors.append([x, y - 1])
        if mapa.is_blocked([x-1,y]) and mapa.is_blocked([x,y+1]):
            if not mapa.is_blocked([x+1,y]):
                neighbors.append([x+1,y])
            if mapa.is_blocked([x+1,y]):
                neighbors.append([x, y - 1])
        if mapa.is_blocked([x+1, y]) and mapa.is_blocked([x,y-1]):
            if not mapa.is_blocked([x - 1, y]):
                neighbors.append([x - 1, y])
            if mapa.is_blocked([x - 1, y]):
                neighbors.append([x, y + 1])
        if mapa.is_blocked([x+1, y]) and mapa.is_blocked([x-1,y]):
            if not mapa.is_blocked([x - 1, y]) and not mapa.is_blocked([x+1,y]):
                neighbors.append([x, y - 1])
                neighbors.append([x,y+1])
            if not mapa.is_blocked([x, y+1]) and mapa.is_blocked([x,y-1]):
                neighbors.append([x , y+1])
            if not mapa.is_blocked([x - 1, y]) and mapa.is_blocked([x+1,y]):
                neighbors.append([x, y - 1])

        return neighbors

    def neighbors2(bomberman, walls):
        [x, y] = bomberman
        neighbors = []

        if [x - 1, y] in walls and [x, y - 1] in walls:
            neighbors.append([x + 2, y - 1])
            neighbors.append([x + 2, y + 1])
        if [x - 1, y] in walls and [x, y + 1] in walls:
            neighbors.append([x + 2, y - 1])
            neighbors.append([x + 2, y + 1])
        if [x + 1, y] in walls and [x, y - 1] in walls:
            neighbors.append([x - 2, y - 1])
            neighbors.append([x - 2, y + 1])
        if [x + 1, y] in walls and [x, y + 1] in walls:
            neighbors.append([x - 2, y - 1])
            neighbors.append([x - 2, y + 1])


        if [x-1,y] in walls:
            neighbors.append([x+1,y-1])
            #neighbors.append([x+1,y+1])

        if [x+1,y] in walls:
            neighbors.append([x-2,y-1])
            #neighbors.append([x-1,y+1])




        if [x-1,y] in walls and mapa.is_blocked([x,y+1]) and mapa.is_blocked([x,y-1]):
            neighbors.append([x+1,y-1])
            neighbors.append([x+1,y+1])
        if [x+1,y] in walls and mapa.is_blocked([x,y+1]) and mapa.is_blocked([x,y-1]):
            neighbors.append([x-1,y-1])
            neighbors.append([x-1,y+1])

        if mapa.is_blocked([x,y+1]) and mapa.is_blocked([x,y-1]):
            if [x-1,y] in walls:
                neighbors.append([x+1,y-1])

        if mapa.is_blocked([x - 1, y]) and mapa.is_blocked([x + 1, y]):

            if [x,y+1] in walls and [x-1,y-1] in walls:
                neighbors.append([x+1,y-1])
            if [x,y+1] in walls and [x+1,y-1] in walls:
                neighbors.append([x-1,y-1])

            if [x,y-1] in walls and [x+1,y+1] in walls:
                neighbors.append([x-2,y])
            if [x,y-1] in walls and [x-1,y+1] in walls:
                neighbors.append([x+2,y])

            if [x, y + 1] in walls:
                neighbors.append([x + 1, y - 1])
                neighbors.append([x - 1, y - 1])
            if [x,y+1] in walls and [x-1,y+1] in walls:
                neighbors.append([x+1,y-1])
            if [x,y+1] in walls and [x+1,y-1] in walls:
                neighbors.append([x-1,y-1])

            if [x, y - 1] in walls:
                neighbors.append([x - 1, y + 1])
                neighbors.append([x + 1, y + 1])

            if [x-1,y] in walls and [x,y+1] in walls:
                neighbors.append([x+2,y-1])
                neighbors.append([x+2,y+1])

            if (not mapa.is_blocked([x, y + 1]) and mapa.is_blocked([x - 1, y + 1])) or (not mapa.is_blocked([x, y + 1]) and [x - 1, y + 1] in walls):
                neighbors.append([x + 1, y + 1])
                neighbors.append([x + 1, y - 1])
                neighbors.append([x - 1, y - 1])
            if (not mapa.is_blocked([x, y - 1]) and mapa.is_blocked([x - 1, y - 1])) or (not mapa.is_blocked([x, y - 1]) and [x - 1, y - 1]) in walls:
                neighbors.append([x + 1, y - 1])
                neighbors.append([x + 1, y + 1])
                neighbors.append([x - 1, y + 1])
            if (not mapa.is_blocked([x, y + 1]) and mapa.is_blocked([x + 1, y + 1])) or (not mapa.is_blocked([x, y + 1]) and [x + 1, y + 1] in walls):
                neighbors.append([x - 1, y - 1])
                neighbors.append([x - 1, y + 1])
                neighbors.append([x + 1, y - 1])
            if (not mapa.is_blocked([x, y - 1]) and mapa.is_blocked([x + 1, y - 1])) or (not mapa.is_blocked([x, y - 1]) and [x + 1, y - 1] in walls):
                neighbors.append([x - 1, y - 1])
                neighbors.append([x - 1, y + 1])
                neighbors.append([x + 1, y + 1])

        if [x, y + 1] in walls:
            if [x - 2, y] in walls:
                neighbors.append([x + 1, y - 2])
            if [x + 2, y] in walls:
                neighbors.append([x - 1, y - 2])
                neighbors.append([x - 1, y + 2])
        if [x, y - 1] in walls:
            if [x - 2, y] in walls:
                neighbors.append([x + 1, y - 2])
                neighbors.append([x + 1, y + 2])
            if [x + 2, y] in walls:
                neighbors.append([x - 1, y + 2])
                neighbors.append([x - 1, y - 2])


        if mapa.is_blocked([x, y - 1]) and mapa.is_blocked([x, y + 1]):
            if [x - 1, y] in walls:
                neighbors.append([x + 1, y - 1])
                neighbors.append([x + 1, y + 1])
            if [x + 1, y] in walls:
                neighbors.append([x - 1, y - 1])
                neighbors.append([x - 1, y + 1])
            if not mapa.is_blocked([x + 1, y]) and mapa.is_blocked([x + 1, y - 1]):
                neighbors.append([x + 1, y + 1])
            if not mapa.is_blocked([x + 1, y]) and mapa.is_blocked([x + 1, y + 1]):
                neighbors.append([x + 1, y - 1])
            if not mapa.is_blocked([x - 1, y]) and not mapa.is_blocked([x + 1, y ]):
                neighbors.append([x + 1, y + 1])
                neighbors.append([x - 1, y + 1])
                neighbors.append([x + 1, y - 1])
                neighbors.append([x - 1, y - 1])


            if [x,y+1] in walls and [x,y-1] in walls and [x+1,y] in walls:
                neighbors.append([x-2,y-1])
                neighbors.append([x-2,y+1])
            if [x,y+1] in walls and [x,y-1] in walls and [x-1,y] in walls:
                neighbors.append([x+2,y-1])
                neighbors.append([x+2,y+1])
            if [x+1,y] in walls and [x-1,y] in walls and [x,y+1] in walls:
                neighbors.append([x-1,y-2])
                neighbors.append([x+1,y-2])
            if [x+1,y] in walls and [x-1,y] in walls and [x,y-1] in walls:
                neighbors.append([x-1,y+2])
                neighbors.append([x+1,y+2])

            if [x,y+1] in walls and [x+2,y] in walls:
                neighbors.append([x+1,y+2])
                neighbors.append([x-1,y+2])
                neighbors.append([x - 2, y + 1])
                neighbors.append([x - 2, y - 1])

            if [x,y+1] in walls and [x+1,y] in walls:
                neighbors.append([x-1,y+1])
                neighbors.append([x,y+2])
                neighbors.append([x - 2, y + 1])
                neighbors.append([x - 2, y - 1])

            if [x,y+1] in walls and [x-1,y] in walls:
                neighbors.append([x-1,y+2])
                neighbors.append([x+1,y+2])
                neighbors.append([x + 2, y + 1])
                neighbors.append([x + 2, y - 1])

            if [x,y-1] in walls and [x+1,y] in walls:
                neighbors.append([x-1,y-1])
                neighbors.append([x+1,y-1])

            if [x,y-1] in walls and [x-1,y] in walls:
                neighbors.append([x-1,y-2])
                neighbors.append([x+1,y-2])


            if not mapa.is_blocked([x - 1, y]) and mapa.is_blocked([x - 1, y - 1]):
                neighbors.append([x - 1, y + 1])
                neighbors.append([x,y+2])
            if not mapa.is_blocked([x + 1, y]) and mapa.is_blocked([x + 1, y + 1]):
                neighbors.append([x + 1, y - 1])
                neighbors.append([x,y-2])
            if not mapa.is_blocked([x - 1, y]) and mapa.is_blocked([x - 1, y + 1]):
                neighbors.append([x + 1, y - 1])
                neighbors.append([x, y - 2])
        if not mapa.is_blocked([x, y + 1]) and not mapa.is_blocked([x, y - 1]):
            if [x - 1, y] in walls:
                neighbors.append([x - 1, y + 2])
                neighbors.append([x - 1, y - 2])
            if [x + 1, y] in walls:
                neighbors.append([x + 1, y - 2])
                neighbors.append([x + 1, y + 2])
            #if [x+1,y-1] in walls or [x+1,y-1]:
             #   neighbors.append([x-1,y-1])
              #  neighbors.append([x-1,y+1])
            #if [x-1,y-1] in walls or [x-1,y-1]:
             #   neighbors.append([x+1,y-1])
              #  neighbors.append([x+1,y+1])

        if not mapa.is_blocked([x + 1, y]) and not mapa.is_blocked([x - 1, y]) and not mapa.is_blocked(
                [x, y + 1]) and not mapa.is_blocked([x, y - 1]):


            if [x+1,y] in walls and [x+1,y-2] in walls:
                neighbors.append([x-2,y-1])
                neighbors.append([x - 2, y + 1])
            if [x-1,y] in walls and [x-1,y-2] in walls:
                neighbors.append([x+2,y-1])
                neighbors.append([x + 2, y + 1])

            if [x+1,y] in walls and [x-1,y-2] in walls:
                neighbors.append([x-2,y-1])
                neighbors.append([x - 2, y + 1])
            if [x-1,y] in walls and [x+1,y-2] in walls:
                neighbors.append([x+2,y-1])
                neighbors.append([x + 2, y + 1])

            if ([x + 1, y]) in walls and ([x + 1, y - 2]) in walls and ([x, y - 3]) in walls:
                neighbors.append([x - 2, y - 1])
                neighbors.append([x - 2, y + 1])
            if ([x - 1, y]) in walls and ([x - 1, y - 2]) in walls and ([x, y - 3]) in walls:
                neighbors.append([x + 2, y - 1])
                neighbors.append([x + 2, y + 1])
            if ([x, y+1]) in walls and ([x + 1, y]) in walls and ([x+1, y - 2]) in walls:
                neighbors.append([x -2, y - 1])
                neighbors.append([x -2, y + 1])
            if ([x - 1, y]) in walls and ([x - 1, y - 2]) in walls and ([x, y +1]) in walls:
                neighbors.append([x + 2, y - 1])
                neighbors.append([x + 2, y + 1])

            if [x,y+1] in walls:
                neighbors.append([x-2,y-1])
                neighbors.append([x+2,y-1])
                neighbors.append([x - 2, y + 1])
                neighbors.append([x + 2, y + 1])

            if [x,y-1] in walls:
                neighbors.append([x - 2, y - 1])
                neighbors.append([x + 2, y - 1])
                neighbors.append([x - 2, y + 1])
                neighbors.append([x + 2, y + 1])

            if [x-1,y] in walls and [x,y+1] in walls and [x+1,y] in walls:
                neighbors.append([x-1,y-2])
                neighbors.append([x+1,y-2])
            if [x-1,y] in walls and [x,y-1] in walls and [x+1,y] in walls:
                neighbors.append([x-1,y+2])
                neighbors.append([x+1,y+2])

            if [x,y+1] in walls and [x-1,y] in walls and [x,y-1] in walls:
                neighbors.append([x+2,y-1])
                neighbors.append([x+2,y+1])
            if [x,y+1] in walls and [x+1,y] in walls and [x,y-1] in walls:
                neighbors.append([x-2,y+1])
                neighbors.append([x-2,y-1])

            if [x,y-1] in walls and [x,y+1] in walls:
                neighbors.append([x-2,y-1])
                neighbors.append([x-2,y+1])
                neighbors.append([x +2, y - 1])
                neighbors.append([x + 2, y + 1])
            if [x-1,y] in walls and [x+1,y] in walls:
                neighbors.append([x-1,y-2])
                neighbors.append([x + 1, y - 2])
                neighbors.append([x+1,y+2])
                neighbors.append([x- 1, y + 2])


            if [x-1,y] in walls and [x,y-1] in walls :
                neighbors.append([x+2,y-1])
                neighbors.append([x+2,y+1])
            if [x - 1, y] in walls and [x, y + 1] in walls:
                neighbors.append([x+2,y-1])
                neighbors.append([x+2,y+1])
            if [x+1,y] in walls and [x,y-1] in walls:
                neighbors.append([x-2,y-1])
                neighbors.append([x-2,y+1])
            if [x+1,y] in walls and [x,y+1] in walls:
                neighbors.append([x-2,y-1])
                neighbors.append([x-2,y+1])

        elif not mapa.is_blocked([x + 1, y]) and not mapa.is_blocked([x - 1, y]) and (
                [x, y - 1] in walls or [x, y + 1] in walls):
            if [x, y + 1] in walls:
                neighbors.append([x - 2, y + 1])
                neighbors.append([x + 2, y + 1])

            if [x, y - 1] in walls:
                neighbors.append([x - 2, y - 1])
                neighbors.append([x + 2, y - 1])
        elif not mapa.is_blocked([x - 1, y]) and mapa.is_blocked([x + 1, y]) and (
                [x, y + 1] in walls or [x, y - 1] in walls):
            if [x, y + 1] in walls:
                neighbors.append([x - 1, y - 2])
            if [x, y - 1] in walls:
                neighbors.append([x - 1, y + 2])
        elif not mapa.is_blocked([x + 1, y]) and mapa.is_blocked([x - 1, y]) and (
                [x, y + 1] in walls or [x, y - 1] in walls):
            if [x, y + 1] in walls:
                neighbors.append([x + 1, y - 2])
            if [x, y - 1] in walls:
                neighbors.append([x + 1, y + 2])
        elif not mapa.is_blocked([x, y + 1]) and mapa.is_blocked([x, y - 1]) and (
                [x + 1, y] in walls or [x - 1, y] in walls):
            if [x + 1, y] in walls:
                neighbors.append([x - 2, y + 1])
            if [x - 1, y] in walls:
                neighbors.append([x + 2, y + 1])
        elif not mapa.is_blocked([x, y - 1]) and mapa.is_blocked([x, y + 1]) and (
                [x + 1, y] in walls or [x - 1, y] in walls):
            if [x + 1, y] in walls:
                neighbors.append([x - 2, y - 1])
            if [x - 1, y] in walls:
                neighbors.append([x + 2, y - 1])

        #elif mapa.is_blocked([x, y + 1]):
         #   neighbors.append([x - 1, y - 2])
          #  neighbors.append([x + 1, y - 2])

        #elif mapa.is_blocked([x, y - 1]):
         #   neighbors.append([x - 1, y + 2])
          #  neighbors.append([x + 1, y + 2])

        #elif mapa.is_blocked([x - 1, y]):
         #   neighbors.append([x + 2, y + 1])
          #  neighbors.append([x + 2, y - 1])

        #elif mapa.is_blocked([x + 1, y]):
         #   neighbors.append([x - 2, y + 1])
          #  neighbors.append([x - 2, y - 1])
           # ...
        for a in neighbors:
            [xa,ya] = a
            if mapa.is_blocked([xa, ya]) or [xa, ya] in walls:
                neighbors.remove(a)
        return neighbors[0]

    def getPath(bomber, objective):
        [x, y] = bomber
        z = x - 1
        ret = (x, y + 1)
        ret1 = (x, y - 1)
        ret2 = (x - 1, y)
        ret3 = []
        tovisit = []
        listofP = []
        aux = 0
        tovisit.append(bomber)

        while tovisit != []:
            aux = aux + 1
            if aux == 20000:
                listofP = []
                ret3 = neighbors(bomber)
                listofP.append(random.choice(ret3))
                return listofP

            current = tovisit.pop(0)
            # print(current)
            listofP.append(current)
            if current == objective:
                break
            nodes = neighbors(current)
            nodetoapp = nodes[0]
            minimo = distanceTo(nodes[0], objective)
            for x in nodes:
                if distanceTo(x,
                              objective) < minimo:  # and x != listofP[len(listofP)-2]: #and lastP of listofP  != x # and x != listofP[len(listofP)-1]: #and lastP of listofP  != x
                    nodetoapp = x
                    minimo = distanceTo(x, objective)
            tovisit.append(nodetoapp)
        listofP.append(current)
        return listofP[1:]

    def heuristic(p1, p2):
        pass
        # definir funções até aqui

    def is_enemies_in_path(path,enemiesP):
        for en in enemiesP:
            [xe,ye] = en
            for p in path:
                [x,y] = p
                print(p)
                print(en)
                if [x,y] == [xe,ye]:
                    print('ola')
                    return True
                else:
                    return False

    async with websockets.connect(f"ws://{server_address}/player") as websocket:

        # Receive information about static game properties
        await websocket.send(json.dumps({"cmd": "join", "name": agent_name}))
        msg = await websocket.recv()
        game_properties = json.loads(msg)

        # You can create your own map representation or use the game representation:
        mapa = Map(size=game_properties["size"], mapa=game_properties["map"])
        # Next 3 lines are not needed for AI agent
        # SCREEN = pygame.display.set_mode((299, 123))
        # SPRITES = pygame.image.load("data/pad.png").convert_alpha()
        # SCREEN.blit(SPRITES, (0, 0))
        path = []
        state1 = []
        obj = [15, 29]
        obj1 = [16, 27]
        while True:
            state = json.loads(await websocket.recv())
            bomberman = state["bomberman"]
            bomba = state["bombs"]
            lives = state["lives"]
            walls = state["walls"]
            portal = state["exit"]
            enemies = state['enemies']
            powerup = state['powerups']
            enemiesP = []
            #state1.append(bomberman)
            #if len(state1) ==5:
             #   if checkEqual(state1):
              #      path=[]
              #  else:

            for e in state.get('enemies'):
                enemiesP.append(e['pos'])



            if len(path) == 0:


                if powerup != []:
                    path = getPath(bomberman, powerup[0][0])
                elif len(enemiesP) == 0 and portal != []:
                    path = getPath(bomberman, portal)
                elif bomba != [] and not x and len(walls) == 0:
                    path = getPath(bomberman, obj1)
                    x = True
                elif bomba != [] and not x:
                    path = getPath(bomberman, neighbors2(bomberman, walls))
                    x = True
                elif bomba != []:
                    path.append(bomberman)
                elif len(walls) == 0 and len(enemiesP) != 0:
                    path = getPath(bomberman, obj)
                    x = False
                else:
                    path = getPath(bomberman, objective(bomberman, walls, enemies))
                    x = False


            else:
                #if (len(walls) != 0) and len(enemiesP) != 0:
                 #   if (is_enemies_in_path(path, enemiesP) == 1):
                  #      path =[]
                   #     path = getPath(bomberman,getPath(bomberman, neighbors2(bomberman, walls)))

                if len(walls) == 0:
                    await websocket.send(json.dumps(
                        {"cmd": "key", "key": pressKey(bomberman, path.pop(0), obj, bomba, enemiesP, walls,path)}))

                else:
                    await websocket.send(json.dumps({"cmd": "key", "key": pressKey(bomberman, path.pop(0),
                                                                                   objective(bomberman, walls, enemies),
                                                                                   bomba, enemiesP, walls,path)}))
            # try:
            # receive game state, this must be called timely or your game will get out of sync with the server

            # Next lines are only for the Human Agent, the key values are nonetheless the correct ones!
            # except websockets.exceptions.ConnectionClosedOK:
            #    print("Server has cleanly disconnected us")
            #    return

            # Next line is not needed for AI agent
            # pygame.display.flip()


# DO NOT CHANGE THE LINES BELLOW
# You can change the default values using the command line, example:
# $ NAME='bombastico' python3 client.py
loop = asyncio.get_event_loop()
SERVER = os.environ.get("SERVER", "localhost")
PORT = os.environ.get("PORT", "8000")
NAME = os.environ.get("NAME", getpass.getuser())
loop.run_until_complete(agent_loop(f"{SERVER}:{PORT}", NAME))


