import sys
import json
import asyncio
import websockets
import getpass
import os
import math
import random
import time
from characters import *
from game import *
from mapa import Map


# Next 2 lines are not needed for AI agent
# import pygame
# pygame.init()
# funcao de encontrar para onde ir
async def agent_loop(server_address="localhost:8000", agent_name="student"):
    def objective(state):
        [px, py] = state["bomberman"]
        posible = [[px - 1, py - 1], [px - 2, py - 1], [px - 1, py - 2], [px + 1, py - 1], [px + 2, py - 1],
                   [px + 1, py - 2], [px - 1, py + 1], [px - 2, py + 1], [px - 1, py + 2], [px + 1, py + 1],
                   [px + 2, py + 1], [px + 1, py + 2]]
        array = []
        lista2 = []
        safepos = []
        if state["bombs"] != []:
            safespots = neighbors_esc(state["bomberman"], state)
            for x in safespots:
                safespots = safespots + neighbors_esc(x, state)
            for y in safespots:
                if y in posible:
                    safepos.append(y)
            if safepos == []:
                for z in safespots:
                    safespots = safespots + neighbors_esc(z, state)
                for f in safespots:
                    if f in posible:
                        safepos.append(f)
            if state["powerups"] != [] and state["powerups"][0][1] == "Detonator" and state["powerups"][0][0] in safespots:
                safespots.remove(state["powerups"][0][0])
            # comparar posições seguras com o inimigo mais proximo
            en = posofcloseEn(state)
            retVar = safepos[0]
            print(safepos)
            dist = 0
            for e in safepos:
                if distanceTo(en, e) > dist:
                    dist = distanceTo(en, e)
                    retVar = e
            return retVar
            # posição segura
        else:
            # encontrar o inimigo ou parede mais perto
            lista = [(math.sqrt((px - x) ** 2 + (py - y) ** 2), x, y) for x in range(1, mapa.hor_tiles) for y in
                     range(1, mapa.ver_tiles) if [x, y] in state["walls"]]  # 1 ou 0 no x?
            if lista == []:
                return [15, 29]
            else:
                sortedList = sorted(lista, key=lambda l: l[0])  # encontra a wall mais proxima
                x1, y1, z1 = sortedList[0]
                if mapa.map[y1][z1 - 1] == 0:  # encontra uma posição livre perto da wall mais próxima
                    array.append([math.sqrt((px - y1) ** 2 + (py - (z1 - 1)) ** 2), y1, (z1 - 1)])
                if mapa.map[y1 - 1][z1] == 0:
                    array.append([math.sqrt((px - (y1 - 1)) ** 2 + (py - z1) ** 2), (y1 - 1), z1])
                if mapa.map[y1 + 1][z1] == 0:
                    array.append([math.sqrt((px - (y1 + 1)) ** 2 + (py - z1) ** 2), (y1 + 1), z1])
                if mapa.map[y1][z1 + 1] == 0:
                    array.append([math.sqrt((px - y1) ** 2 + (py - (z1 + 1)) ** 2), y1, (z1 + 1)])
                sortedList1 = sorted(array, key=lambda l: l[0])
                # z2, y2, x2 = sortedList1[0]
                for z in state["enemies"]:
                    [x, y] = z["pos"]
                    lista2.append([(math.sqrt((px - x) ** 2 + (py - y) ** 2)), x, y])  # mexi aqui
                sortedList2 = sorted(lista2, key=lambda x: x[0])
                sortedList2 = sortedList2 + sortedList1
                sortedList2 = sorted(sortedList2, key=lambda x: x[0])
                z1, x1, y1 = sortedList1[0]  # sortedList2 tem inimigos
                return x1, y1

    def neighbors_esc(cel, state):
        [x, y] = cel
        neighbors = []
        if not mapa.is_blocked([x - 1, y]):
            neighbors.append([x - 1, y])
        if not mapa.is_blocked([x + 1, y]):
            neighbors.append([x + 1, y])
        if not mapa.is_blocked([x, y - 1]):
            neighbors.append([x, y - 1])
        if not mapa.is_blocked([x, y + 1]):
            neighbors.append([x, y + 1])
        for x in neighbors:
            if x in state["walls"]:
                neighbors.remove(x)
        return neighbors

    def getPath(state, objective):
        bomber = state["bomberman"]
        [x, y] = bomber
        tovisit = []
        listofP = []
        tovisit.append(bomber)
        w, z = objective
        goal = [w, z]
        while tovisit != []:
            current = tovisit.pop(0)
            listofP.append(current)
            if current == goal:
                break
            nodes = neighbors(current)
            nodetoapp = nodes[0]
            minimo = distanceTo(nodes[0], objective)
            for x in nodes:
                if x not in listofP:  # new line
                    if distanceTo(x,
                                  objective) < minimo:  # and x != listofP[len(listofP)-2]: #and lastP of listofP  != x # and x != listofP[len(listofP)-1]: #and lastP of listofP  != x
                        nodetoapp = x
                        minimo = distanceTo(x, objective)
            tovisit.append(nodetoapp)
        listofP.append(current)
        if state["bombs"] != []:
            for x in range(0, 5):
                listofP.append(current)
                #if state["powerups"] != [] and state["powerups"][0][1] == "Detonator" and state["powerups"][0][0] in listofP:
                 #   flag =1
        return listofP[1:]

    def distanceTo(celula, objective):
        [x, y] = celula
        [x1, y1] = objective
        return math.sqrt((x - x1) ** 2 + (y - y1) ** 2)

    def neighbors(celula):
        [x, y] = celula
        neighbors = []
        if not mapa.is_blocked([x - 1, y]):
            neighbors.append([x - 1, y])
        if not mapa.is_blocked([x + 1, y]):
            neighbors.append([x + 1, y])
        if not mapa.is_blocked([x, y - 1]):
            neighbors.append([x, y - 1])
        if not mapa.is_blocked([x, y + 1]):
            neighbors.append([x, y + 1])
        if mapa.is_blocked([x - 1, y]):
            if not mapa.is_blocked([x + 1, y]):
                neighbors.append([x + 1, y])
            if mapa.is_blocked([x + 1, y]):
                neighbors.append([x, y + 1])
                neighbors.append([x, y - 1])
        if mapa.is_blocked([x + 1, y]):
            if not mapa.is_blocked([x - 1, y]):
                neighbors.append([x - 1, y])
            if mapa.is_blocked([x - 1, y]):
                neighbors.append([x, y - 1])
        if mapa.is_blocked([x - 1, y]) and mapa.is_blocked([x, y + 1]):
            if not mapa.is_blocked([x + 1, y]):
                neighbors.append([x + 1, y])
            if mapa.is_blocked([x + 1, y]):
                neighbors.append([x, y - 1])
        if mapa.is_blocked([x + 1, y]) and mapa.is_blocked([x, y - 1]):
            if not mapa.is_blocked([x - 1, y]):
                neighbors.append([x - 1, y])
            if mapa.is_blocked([x - 1, y]):
                neighbors.append([x, y + 1])
        if mapa.is_blocked([x + 1, y]) and mapa.is_blocked([x - 1, y]):
            if not mapa.is_blocked([x - 1, y]) and not mapa.is_blocked([x + 1, y]):
                neighbors.append([x, y - 1])
                neighbors.append([x, y + 1])
            if not mapa.is_blocked([x, y + 1]) and mapa.is_blocked([x, y - 1]):
                neighbors.append([x, y + 1])
            if not mapa.is_blocked([x - 1, y]) and mapa.is_blocked([x + 1, y]):
                neighbors.append([x, y - 1])
        return neighbors

    def posofcloseEn(state):
        lista2 = []
        [px, py] = state["bomberman"]
        for z in state["enemies"]:
            [x, y] = z["pos"]
            lista2.append([(math.sqrt((px - x) ** 2 + (py - y) ** 2)), x, y])  # mexi aqui
        if lista2 == []:
            return [15, 29]
        sortedList2 = sorted(lista2, key=lambda x: x[0])
        z3, x3, y3 = sortedList2[0]
        return x3, y3

    def pressKey(celula, state,flag,flagde):
        [x, y] = celula
        [x1, y1] = objective(state)
        bx, by = state["bomberman"]
        ex, ey = posofcloseEn(state)
        # mandar bombar quando os inimigos estão perto
        #if ((bx == ex and (by <= ey + 3 and by >= ey - 3) and bx % 2 != 0) or (
         #       by == ey and (bx <= ex + 3 and bx >= ex - 3) and by % 2 != 0)) and state["walls"] != []:
          #  return "B"
        elist = []
        plist = []
        plist.append([bx + 1, by])
        plist.append([bx + 2, by])
        plist.append([bx + 3, by])
        plist.append([bx - 1, by])
        plist.append([bx - 2, by])
        plist.append([bx - 3, by])
        plist.append([bx, by + 1])
        plist.append([bx, by + 2])
        plist.append([bx, by + 3])
        plist.append([bx, by - 1])
        plist.append([bx, by - 2])
        plist.append([bx, by - 3])
        for z in state["enemies"]:
            elist.append(z["pos"])
        if  mapa.is_blocked([x + 1, y]) and  mapa.is_blocked([x - 1, y]) and  mapa.is_blocked(
                [x, y + 1]) and  mapa.is_blocked([x, y - 1]):
            for e in elist:
                if e in plist:
                    path =[]
                    if flag == 0:
                        return 'B'
                    if flag ==1:
                        return 'A'
        if bx < x and by == y:
            return "d"
        if bx > x and by == y:
            return "a"
        if by < y and bx == x:
            return "s"
        if by > y and bx == x:
            return "w"
        if bx == x and by == y:
            if state["bombs"] == [] and [x1, y1] == [x, y]:
                #print("flag esta a")
                #print(flag)
                if flag == False:
                    return 'B'
                if flag == True:
                  #  print("flagz ativa")
                   # flagde = True
                    return 'B'

            else:
                return ""
        else:
            return ""

    # def safe(state):
    # x,y = state["bombs"][0][0]
    # bx,by = state["bomberman"]
    # if x != bx and y != by:
    # return True
    # return False
    async with websockets.connect(f"ws://{server_address}/player") as websocket:

        # Receive information about static game properties
        await websocket.send(json.dumps({"cmd": "join", "name": agent_name}))
        msg = await websocket.recv()
        game_properties = json.loads(msg)

        # You can create your own map representation or use the game representation:
        mapa = Map(size=game_properties["size"], mapa=game_properties["map"])

        # Next 3 lines are not needed for AI agent
        # SCREEN = pygame.display.set_mode((299, 123))
        # SPRITES = pygame.image.load("data/pad.png").convert_alpha()
        # SCREEN.blit(SPRITES, (0, 0))
        path = []
        flag = False
        flagde = False
        cnt = 0
        while True:
            state = json.loads(
                await websocket.recv())  # receive game state, this must be called timely or your game will get out of sync with the server
            if len(path) == 0:
                if state["powerups"] != []  and state["walls"] != []:
                    #flag = True
                    #print(state["powerups"][0][1])
                    if state["powerups"][0][1] == "Detonator":
                        #print("ativei a flag")

                        path = getPath(state, state["powerups"][0][0])
                        flag = True
                    else:
                        print(" n ativei a flag")
                        path = getPath(state, state["powerups"][0][0])

                elif len(state["enemies"]) == 0 and len(state["exit"]) != 0:
                    path = getPath(state, state["exit"])
                    #if state["powerups"]!= [] and (state["powerups"][0][1] == "Detonator"):
                     #   for e in path:
                      #      if state["powerups"][0][0] ==e:
                       #         path= getPath(state,objective(state))
                #elif len(state["bombs"]) == [] and flag==True:
                    #cnt+1
                    #print("vou contar")
                    #key = 'A'
                    #await websocket.send(json.dumps({"cmd": "key",
                     #                                "key": key}))
                #elif len(state["bombs"]) != [] and cnt > 25:
                 #   print("detonador ativo")
                  #  key = 'A'
                   # await websocket.send(json.dumps({"cmd": "key",
                    #                                 "key": key}))
                else:
                    #print("aqui")
                    #print("flagz esta")
                    #print(flagde)
                    path = getPath(state, objective(state))
                    #if state["powerups"]!=[] and (state["powerups"][0][1] == "Detonator"):
                     #   for e in path:
                      #      if state["powerups"][0][0] ==e:
                       #         path= getPath(state,objective(state))
            else:
                print("aqui")
                key = pressKey(path.pop(0), state,flag,flagde)

                await websocket.send(json.dumps({"cmd": "key",
                                                 "key": key}))  # send key command to server - you must implement this send in the AI agent
                if key == "B":
                    path = []
                if key == "B" and flag == True:
                    path = []
                    print("A")
                    keyf = "A"
                    await websocket.send(json.dumps({"cmd": "key","key": keyf}))
                #elif len(state["bombs"]) != [] and flagz==True:
                 #   cnt+1
                  #  print("vou contar")
                #elif  cnt==4:
                 #   print("detonador ativo")
                  #  key = 'A'
                   # await websocket.send(json.dumps({"cmd": "key",
                    #                                 "key": key}))


            # Next line is not needed for AI agent
            # pygame.display.flip()


# DO NOT CHANGE THE LINES BELLOW
# You can change the default values using the command line, example:
# $ NAME='bombastico' python3 client.py
loop = asyncio.get_event_loop()
SERVER = os.environ.get("SERVER", "localhost")
PORT = os.environ.get("PORT", "8000")
NAME = os.environ.get("NAME", getpass.getuser())
loop.run_until_complete(agent_loop(f"{SERVER}:{PORT}", NAME))