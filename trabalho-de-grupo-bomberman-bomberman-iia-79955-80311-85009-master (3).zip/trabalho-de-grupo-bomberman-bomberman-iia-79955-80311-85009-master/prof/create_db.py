from grading import db

db.create_all()
